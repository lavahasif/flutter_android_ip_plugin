package com.shersoft.android_ip_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
